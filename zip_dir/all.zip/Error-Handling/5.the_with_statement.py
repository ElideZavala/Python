# -------------------------------------------------------------------------------------
# ***** The with Statement *****

#! Opening a single fileb
print("******************* Example 15 *********************")

# __exit__

# try:
#     with open("someFil.txt") as note:
#         print("File opened..." + note.name)

#     age = int(input("Age: "))
#     x = 10 / age
# except (ValueError, ZeroDivisionError):
#     print("Plese enter a valid age")
# except FileNotFoundError:
#     print("oops")
# else:
#     print("No Exceptions Here")

#! Opening multiple files
print("******************* Example 16 *********************")
# try:
#     with open("someFile.txt") as note, open("anotherFile.txt") as my_note:
#         print("File opened..." + note.name + " & " + my_note.name)

#     # age = int(input("Age: "))
#     # x = 10 / age
# except (ValueError, ZeroDivisionError):
#     print("Plese enter a valid age")
# except FileNotFoundError:
#     print("file was not found...")
# else:
#     print("No Exceptions Here")
