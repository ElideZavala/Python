# -----------------------------------------------------------------------------------
# What are Exceptions?

# Syntax Error
# Logical Error( Exceptions )

print("******************** Example 1 ********************")
# if 3 > 1  # Syntax Error for missing colon

print("******************** Example 2 ********************")
# 1/0  # Traceback (most recent call last): ZeroDivisionError: division by zero

print("******************** Example 3 ********************")
# numbers = [1, 2]
# print(numbers[3]) # IndexError: list index out of range

print("******************** Example 4 ********************")
age = int(input("age:"))
